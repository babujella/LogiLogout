package LoginLogout;

public class SecurityWebinitializer extends AbstractSecurityWebApplicationInitializer {

}
